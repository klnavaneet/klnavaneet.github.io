%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Date of modification 16/10/2014
% Code to compute beats per minute (bpm) from a given ECG signal
% Steps- demean, threshold for posiitve values,
% run a window of 8s (125 Hz is the samploing rate) with a shift of 2s,
% in each window compute auto-correlation to get the approximate distance
% between two peaks,
%%
clc;
clear;
close all;
%%
all_data{1}='DATA_01_TYPE01';
all_data{2}='DATA_02_TYPE02';
all_data{3}='DATA_03_TYPE02';
all_data{4}='DATA_04_TYPE02';
all_data{5}='DATA_05_TYPE02';

n_pts=4096;
wind_sz=[6 10 6 10 6];

for i=1:length(all_data)
    for j=1
        sig=[];
        load(['..\data\' all_data{i} '.mat']) %load the signal file
        load(['..\data\' all_data{i} '_BPMtrace.mat']) %load the annotated BPM
        bpm=compute_bpm_spt(sig(j,:),n_pts, wind_sz(i));
        err=sum(abs(bpm'-BPM0(1:length(bpm))))/length(bpm);
        figure; plot(bpm,'linewidth',2), title(['Length of BPM from ECG: Comp' num2str(length(bpm)) ';Anno:' num2str(length(BPM0)) ';err' num2str(err)])
        hold on;plot(BPM0, 'r.-');
        legend('Comp', 'Anno')
%         saveas(gcf, ['..\opt_bpm_from_ecg\spectg\comp_plot_' all_data{i} '_signal'  num2str(j) '.tiff'])
    end
end
%%