function loc =spt_peak_sel(spec, prev_loc, wind_width)

% Date of modification 16/10/2014

% window around the previous location
K1=max([prev_loc-wind_width,1]);     
K2=min([prev_loc+wind_width,length(spec)]);

% peak of maximum amplitude in the window
temp=spec(K1:K2);
peak_loc=getpeak(temp);
peak_val=temp(peak_loc);
[val temp_loc]=sort(peak_val, 'descend');
search_peak(1)=peak_loc(temp_loc(1))+K1-1;
loc=search_peak(1);