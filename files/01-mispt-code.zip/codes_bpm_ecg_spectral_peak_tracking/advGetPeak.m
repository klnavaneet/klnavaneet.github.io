function peakLoc=advGetPeak(intProfile)

peakLoc=[];

repVal=repmat(-1, length(intProfile),1);
purIntProf=intProfile(1);
repVal(1)=0;

for i=2:length(intProfile)
    if(intProfile(i) == purIntProf(end))
        repVal(i)=1;
    else
        purIntProf=[purIntProf intProfile(i)];
        repVal(i)=0;
    end
end

peakLocPru=getpeak((round(purIntProf*10000))/10000);
for t=1:length(peakLocPru)
    zerosLoc=find(repVal==0);
    peakLoc(t)= zerosLoc(peakLocPru(t));
end
