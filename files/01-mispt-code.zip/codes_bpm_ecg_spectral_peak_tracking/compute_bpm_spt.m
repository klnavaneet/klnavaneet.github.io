function bpm=compute_bpm_spt(sig, n_pts, wind_width)
% Date of modification 16/10/2014
t=1;
i=1;
wind_size=125*8;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% find peak for the first window

temp_sig=sig(i:i+wind_size-1); %%%% get the signal within window of 8s.
temp=log(abs(fft(temp_sig-mean(temp_sig),n_pts))); %%% fft of th 8s signal 
loc(t)=spt_init(temp, n_pts);
i=i+(125*2); % shift by window of 2s.
t=t+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% find peak for the successive windows
while(i<=length(sig)-wind_size)
    temp_sig=sig(i:i+wind_size-1);
    temp=log(abs(fft(temp_sig-mean(temp_sig),n_pts)));
    loc(t)=spt_peak_sel(temp, loc(t-1),wind_width);
    i=i+(125*2);
    t=t+1;
end
bpm=loc./n_pts.*125.*60;