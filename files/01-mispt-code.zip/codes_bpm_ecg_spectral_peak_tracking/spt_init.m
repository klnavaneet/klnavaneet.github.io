function loc=spt_init(spec, n_pts)
% Date of modification 16/10/2014
% find the location of maximum amplitude.
K1=round(50/60/125*n_pts);
K2=round(300/60/125*n_pts);
[v loc]=max(spec(K1:K2));
loc=loc+K1-1;
