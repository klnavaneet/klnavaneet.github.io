function peakpos=getpeak(sig)

% Oct 15, 2006
% peakpos=getpeak(sig)
% Given a signal vector it finds the peak locations in the signal

lsig=length(sig);
% sigr=sig(2:end);sigl=sig(1:end-1);
rect=-1*ones(1,lsig);
% rect(find(sigr-sigl>=0)+1)=1;
rect(find(diff(sig)>0)+1)=1;
rect(find(diff(sig)==0)+1)=0;

rectnzind=find(rect~=0);
rectnz=rect(rectnzind);

pton_st=rectnzind(find(diff(rectnz)==-2));
pton_en=rectnzind(find(diff(rectnz)==-2)+1);
crit_ind=[];
for i=1:length(pton_st)
    crit_ind=[crit_ind pton_st(i)+1:pton_en(i)-1];
end
rect(crit_ind)=1;

rect_use=rect(2:end);

peakpos=find(diff(rect_use)==-2)+1;